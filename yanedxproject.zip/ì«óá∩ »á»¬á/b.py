import pygame
import sys
import os
import time
import csv

pygame.init()

SCREEN_WIDTH, SCREEN_HEIGHT = pygame.display.Info().current_w, pygame.display.Info().current_h

screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.FULLSCREEN)
pygame.display.set_caption("Простой платформер на Pygame")

WHITE = (255, 255, 255)
GRAY = (100, 100, 100)
BLACK = (0, 0, 0)
RED = (255, 0, 0)

def load_image(name, size=None):
    player_rect = pygame.image.load(name).convert_alpha()
    if size:
        player_rect = pygame.transform.scale(player_rect, size)
    return player_rect

def load_background_image(name):
    background_image = pygame.image.load(name).convert()
    return pygame.transform.scale(background_image, (SCREEN_WIDTH, SCREEN_HEIGHT))

WALK_FRAMES_RIGHT = [load_image(os.path.join("walk", f"walk{i}.png"), (80, 120)) for i in range(1, 9)]
WALK_FRAMES_LEFT = [pygame.transform.flip(frame, True, False) for frame in WALK_FRAMES_RIGHT]

RUN_FRAMES_RIGHT = [load_image(os.path.join("run", f"run{i}.png"), (80, 120)) for i in range(1, 8)]
RUN_FRAMES_LEFT = [pygame.transform.flip(frame, True, False) for frame in RUN_FRAMES_RIGHT]

IDLE_FRAME_RIGHT = load_image(os.path.join("idle", "player.png"), (80, 120))
IDLE_FRAME_LEFT = pygame.transform.flip(IDLE_FRAME_RIGHT, True, False)

JUMP_FRAME = load_image(os.path.join("jump", "jump.png"), (80, 120))

POTION_ICON = pygame.image.load("potionspeed.png").convert_alpha()
POTION_ICON = pygame.transform.scale(POTION_ICON, (75, 75))

player_x = SCREEN_WIDTH // 2 - IDLE_FRAME_RIGHT.get_width() // 2
player_y = SCREEN_HEIGHT - IDLE_FRAME_RIGHT.get_height() - 50
player_rect = IDLE_FRAME_RIGHT.get_rect(topleft=(player_x, player_y))
player_speed_walk = 2
player_speed_run = 5

gravity = 0.2
player_y_speed = 0

frame_index = 0
animation_speed = 6
animation_timer = 0

is_walking = False
is_running = False
is_facing_left = False

is_jumping = False
jump_strength = -7

is_potion_active = False
potion_timer = 0
potion_cooldown = 15 * 60
potion_cooldown_timer = 0

obstacles = [
    pygame.Rect(500, 980, 100, 50),
    pygame.Rect(500, 300, 80, 60),
]

current_frame = IDLE_FRAME_RIGHT

font = pygame.font.SysFont(None, 50)

def draw_text(text, font, color, surface, x, y):
    text_obj = font.render(text, True, color)
    text_rect = text_obj.get_rect()
    text_rect.center = (x, y)
    surface.blit(text_obj, text_rect)

def main_menu():
    running = True
    background = load_background_image("background.png")
    while running:
        screen.blit(background, (0, 0))
        mouse_pos = pygame.mouse.get_pos()
        play_button = pygame.Rect(SCREEN_WIDTH // 2 - 125, SCREEN_HEIGHT // 2, 250, 60)
        quit_button = pygame.Rect(SCREEN_WIDTH // 2 - 125, SCREEN_HEIGHT // 2 + 100, 250, 60)
        records_button = pygame.Rect(SCREEN_WIDTH // 2 - 125, SCREEN_HEIGHT // 2 + 200, 250, 60)
        pygame.draw.rect(screen, GRAY, play_button, border_radius=5)
        pygame.draw.rect(screen, GRAY, quit_button, border_radius=5)
        pygame.draw.rect(screen, GRAY, records_button, border_radius=5)
        draw_text("Играть", font, WHITE, screen, SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2 + 30)
        draw_text("Выйти", font, WHITE, screen, SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2 + 130)
        draw_text("Рекорды", font, WHITE, screen, SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2 + 230)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if play_button.collidepoint(mouse_pos):
                    game_loop(RED)
                if quit_button.collidepoint(mouse_pos):
                    running = False
                    pygame.quit()
                    sys.exit()
                if records_button.collidepoint(mouse_pos):
                    show_records()
        pygame.display.update()
        pygame.time.Clock().tick(60)

def show_records():
    running = True
    background = load_background_image("background2.png")
    while running:
        screen.blit(background, (0, 0))
        sp1 = []
        records = []
        with open('records.csv', encoding="utf8") as csvfile:
            reader = csv.reader(csvfile, delimiter=';', quotechar='"')
            for i in reader:
                records.append(str(i))
            csvfile.close()
        rc = tuple(records)
        y_offset = 150
        for record in rc:
            if record not in sp1:
                draw_text(record[2:-2], font, WHITE, screen, SCREEN_WIDTH // 2, y_offset)
                sp1.append(record)
                y_offset += 60
        quit_button = pygame.Rect(SCREEN_WIDTH // 2 - 125, SCREEN_HEIGHT - 100, 250, 60)
        pygame.draw.rect(screen, GRAY, quit_button, border_radius=5)
        draw_text("Назад", font, WHITE, screen, SCREEN_WIDTH // 2, SCREEN_HEIGHT - 70)
        mouse_pos = pygame.mouse.get_pos()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if quit_button.collidepoint(mouse_pos):
                    return
        pygame.display.update()
        pygame.time.Clock().tick(60)

def game_loop(obstacle_color):
    global player_x, player_y, player_rect, player_speed_walk, player_speed_run, gravity, player_y_speed, frame_index, animation_timer, is_walking, is_running, is_facing_left, is_jumping, jump_strength, is_potion_active, potion_timer, potion_cooldown, potion_cooldown_timer, current_frame
    start_time = time.time()
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
        keys = pygame.key.get_pressed()
        if keys[pygame.K_a]:
            player_x -= player_speed_run if keys[pygame.K_LSHIFT] else player_speed_walk
            is_walking = True
            is_running = keys[pygame.K_LSHIFT]
            is_facing_left = True
        elif keys[pygame.K_d]:
            player_x += player_speed_run if keys[pygame.K_LSHIFT] else player_speed_walk
            is_walking = True
            is_running = keys[pygame.K_LSHIFT]
            is_facing_left = False
        else:
            is_walking = False
            is_running = False
        player_rect = current_frame.get_rect(topleft=(player_x, player_y))
        if keys[pygame.K_SPACE] and not is_jumping:
            is_jumping = True
            player_y_speed = jump_strength
        if keys[pygame.K_f] and not is_potion_active and potion_cooldown_timer <= 0:
            is_potion_active = True
            player_speed_walk *= 2.5
            player_speed_run *= 2.5
            jump_strength = -9
            potion_timer = 5 * 60
            potion_cooldown_timer = potion_cooldown
        player_y_speed += gravity
        player_y += player_y_speed
        if is_potion_active:
            potion_timer -= 1
            if potion_timer <= 0:
                is_potion_active = False
                player_speed_walk /= 2.5
                player_speed_run /= 2.5
                jump_strength = -7
        if potion_cooldown_timer > 0:
            potion_cooldown_timer -= 1
        if player_x < 0:
            player_x = 0
        elif player_x > SCREEN_WIDTH - IDLE_FRAME_RIGHT.get_width():
            player_x = SCREEN_WIDTH - IDLE_FRAME_RIGHT.get_width()
        if player_y > SCREEN_HEIGHT - IDLE_FRAME_RIGHT.get_height() - 50:
            player_y = SCREEN_HEIGHT - IDLE_FRAME_RIGHT.get_height() - 50
            player_y_speed = 0
            is_jumping = False
        if is_jumping:
            current_frame = JUMP_FRAME
            if is_facing_left:
                current_frame = pygame.transform.flip(current_frame, True, False)
        elif is_walking or is_running:
            animation_timer += 1
            frames = (RUN_FRAMES_LEFT if is_facing_left else RUN_FRAMES_RIGHT) if is_running else (
                WALK_FRAMES_LEFT if is_facing_left else WALK_FRAMES_RIGHT)
            if animation_timer >= animation_speed:
                frame_index = (frame_index + 1) % len(frames)
                animation_timer = 0
            current_frame = frames[frame_index]
        else:
            current_frame = IDLE_FRAME_LEFT if is_facing_left else IDLE_FRAME_RIGHT
        for obstacle in obstacles:
            if player_rect.colliderect(obstacle):
                if keys[pygame.K_a]:
                    player_x += player_speed_run if keys[pygame.K_LSHIFT] else player_speed_walk
                elif keys[pygame.K_d]:
                    player_x -= player_speed_run if keys[pygame.K_LSHIFT] else player_speed_walk
                player_rect.clamp_ip(obstacle)
        screen.fill((50, 50, 50))
        screen.blit(current_frame, (player_x, player_y))
        screen.blit(POTION_ICON, (10, 10))
        if potion_cooldown_timer > 0:
            font = pygame.font.SysFont(None, 36)
            timer_text = font.render(str(potion_cooldown_timer // 60), True, WHITE)
            screen.blit(timer_text, (70, 20))
        for obstacle in obstacles:
            pygame.draw.rect(screen, obstacle_color, obstacle, 2)
        pygame.display.flip()
        end_time = time.time()
        elapsed_time = end_time - start_time
        score = max(1000 - max(0, int((elapsed_time - 10) * 50)), 0)
        if elapsed_time > 10:
            score = max(1000 - int((elapsed_time - 10) * 50), 0)
        if player_x >= SCREEN_WIDTH - IDLE_FRAME_RIGHT.get_width():
            end_game_screen(elapsed_time, score)
        pygame.time.Clock().tick(60)

def end_game_screen(elapsed_time, score):
    running = True
    background = load_background_image("background.png")
    while running:
        screen.blit(background, (0, 0))
        draw_text("КОНЕЦ ИГРЫ", font, WHITE, screen, SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2 - 50)
        draw_text("Время прохождения: {:.2f} секунд".format(elapsed_time), font, WHITE, screen, SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2)
        draw_text("Ваш счет: {} очков".format(score), font, WHITE, screen, SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2 + 50)
        quit_button = pygame.Rect(SCREEN_WIDTH // 2 - 125, SCREEN_HEIGHT // 2 + 100, 250, 60)
        pygame.draw.rect(screen, GRAY, quit_button, border_radius=5)
        draw_text("Выйти", font, WHITE, screen, SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2 + 130)
        with open('records.csv', 'a', newline='', encoding="utf8") as csvfile:
            writer = csv.writer(
            csvfile, delimiter=';', quotechar='"', quoting=csv.QUOTE_MINIMAL)
            writer.writerow([score])
        mouse_pos = pygame.mouse.get_pos()
        csvfile.close()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if quit_button.collidepoint(mouse_pos):
                    running = False
                    pygame.quit()
                    sys.exit()
        pygame.display.update()
        pygame.time.Clock().tick(60)

def pause_menu():
    running = True
    while running:
        screen.fill(BLACK)
        mouse_pos = pygame.mouse.get_pos()
        continue_button = pygame.Rect(SCREEN_WIDTH // 2 - 125, SCREEN_HEIGHT // 2, 250, 60)
        quit_button = pygame.Rect(SCREEN_WIDTH // 2 - 125, SCREEN_HEIGHT // 2 + 100, 250, 60)
        pygame.draw.rect(screen, GRAY, continue_button, border_radius=5)
        pygame.draw.rect(screen, GRAY, quit_button, border_radius=5)
        draw_text("Продолжить", font, WHITE, screen, SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2 + 30)
        draw_text("Выйти", font, WHITE, screen, SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2 + 130)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if continue_button.collidepoint(mouse_pos):
                    return
                if quit_button.collidepoint(mouse_pos):
                    running = False
                    pygame.quit()
                    sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    return
        pygame.display.update()
        pygame.time.Clock().tick(60)

def main():
    while True:
        main_menu()
        game_loop(RED)

main()
pygame.quit()
sys.exit()
